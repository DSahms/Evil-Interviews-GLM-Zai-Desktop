import { NextRequest, NextResponse } from 'next/server'
import { testTtsProvider } from '@/lib/tts/provider'

export const dynamic = 'force-dynamic'
export const maxDuration = 60

// POST /api/tts-providers/[id]/test — connectivity test (real synthesis call)
// Synthesizes a short test string and returns ok=true with metadata, or
// ok=false with an error message.
export async function POST(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params
  const result = await testTtsProvider(id)
  return NextResponse.json(result, { status: result.ok ? 200 : 502 })
}
