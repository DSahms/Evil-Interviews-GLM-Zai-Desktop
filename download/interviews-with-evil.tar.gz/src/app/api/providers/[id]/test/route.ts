import { NextRequest, NextResponse } from 'next/server'
import { testProvider } from '@/lib/llm/provider'

export const dynamic = 'force-dynamic'
export const maxDuration = 30

// POST /api/providers/[id]/test — connectivity test (real chat completions call)
export async function POST(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params
  const result = await testProvider(id)
  return NextResponse.json(result, { status: result.ok ? 200 : 502 })
}
